package com.example

import kotlinx.coroutines.flow.Flow

class ContractRepository(private val contractDao: ContractDao) {

    val allContracts: Flow<List<ContractEntity>> = contractDao.getAllContracts()

    suspend fun saveContract(contract: ContractEntity): Long {
        return contractDao.insertContract(contract)
    }

    suspend fun deleteContract(id: Long) {
        contractDao.deleteContractById(id)
    }

    suspend fun getContractById(id: Long): ContractEntity? {
        return contractDao.getContractById(id)
    }
}
