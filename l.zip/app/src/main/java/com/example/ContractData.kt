package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * أنواع العقود الرسمية المتاحة في التطبيق
 */
enum class ContractType(val titleAr: String, val iconResName: String) {
    REAL_ESTATE("عقد بيع وشراء عقار", "ic_home"),
    CAR_SALE("عقد بيع وشراء سيارة", "ic_directions_car"),
    RENTAL("عقد إيجار سكوني/تجاري", "ic_key")
}

/**
 * بيانات عقد بيع وشراء العقارات (الدور والأراضي السكنية والزراعية)
 */
data class RealEstateContract(
    val contractNo: String = "0025",
    // الطرف الأول ( البائع )
    val sellerName: String = "",
    val sellerAddress: String = "",
    val sellerIdNumber: String = "",
    val sellerPhone: String = "",
    
    // الطرف الثاني ( المشتري )
    val buyerName: String = "",
    val buyerAddress: String = "",
    val buyerIdNumber: String = "",
    val buyerPhone: String = "",
    
    // تفاصيل العقار والبيع
    val propertyType: String = "دار سكني", // دار سكني / قطعة أرض / زراعي
    val propertyArea: String = "", // المساحة بالمتر المربع
    val plotSequenceNo: String = "", // الرقم والتسلسل
    val neighborhood: String = "", // المحلة / المنطقة
    
    val totalPrice: String = "", // بدل البيع المتفق عليه
    val depositPrice: String = "", // العربون الذي تم قبضه
    val remainingPrice: String = "", // الباقي
    
    val contractDate: String = "", // تاريخ تحرير العقد
    val additionalNotes: String = "", // ملاحظات أو شروط إضافية
    
    val witness1Name: String = "", // الشاهد الأول
    val witness2Name: String = ""  // الشاهد الثاني
)

/**
 * بيانات عقد بيع وشراء السيارات (معارض السيارات)
 */
data class CarSaleContract(
    val galleryName: String = "معرض المدى لتجارة السيارات",
    val galleryPhone: String = "",
    val galleryAddress: String = "",
    val contractNo: String = "000100",
    val carLegalOwner: String = "", // المالك الشرعي للسيارة
    val ownerAddress: String = "",
    
    // الطرف الأول (البائع)
    val sellerName: String = "",
    val sellerAddress: String = "",
    val sellerIdNumber: String = "",
    val sellerPhone: String = "",
    
    // الطرف الثاني (المشتري)
    val buyerName: String = "",
    val buyerAddress: String = "",
    val buyerIdNumber: String = "",
    val buyerPhone: String = "",
    
    // مواصفات المركبة
    val carCategory: String = "خصوصي", // خصوصي / أجرة / حمل
    val carBrandAndType: String = "", // نوع السيارة (مثال: تويوتا لاندكروزر)
    val modelYear: String = "", // الموديل
    val color: String = "", // اللون
    val annualRegNumber: String = "", // رقم السنوية / اللوحة
    val engineNumber: String = "", // رقم المحرك
    val chassisNumber: String = "", // رقم الشاسي
    
    // المبالغ المالية
    val totalPrice: String = "", // بدل قدره
    val totalPriceWords: String = "", // المبلغ كتابةً
    val paidAmount: String = "", // المبلغ المستلم
    val remainingAmount: String = "", // المبلغ المتبقي
    
    val contractDate: String = "", // حرر بتاريخ
    val witnessName: String = "", // الشاهد
    val organizerName: String = "" // منظم العقد
)

/**
 * بيانات عقد الإيجار
 */
data class RentalContract(
    val contractNo: String = "1024",
    val sequenceNumber: String = "", // عدد التسلسل
    val doorsNumber: String = "", // رقم الأبواب
    
    val lessorName: String = "", // المؤجر
    val lesseeName: String = "", // المستأجر
    
    val propertyLocation: String = "", // الواقع
    val neighborhood: String = "", // في المحلة
    val alleyNumber: String = "", // زقاق / دار
    val leaseDuration: String = "", // لمدة (مثال: سنة واحدة)
    
    val startDate: String = "", // ابتداءً من
    val endDate: String = "", // إلى نهاية
    
    val rentAmountWords: String = "", // بدل إيجار فقط (كتابة)
    val rentAmountNumber: String = "", // المبلغ بالأرقام
    val returnToLesseeText: String = "", // العائد إلى المستأجر إليه ببدل إيجار...
    
    val signDate: String = "", // كتبت على نسختين ببد كل من الفريقين... في تاريخ
    val additionalClauses: String = "", // فقرات إضافية
    
    val witness1Name: String = "", // الشاهد الأول
    val witness2Name: String = ""  // الشاهد الثاني
)

/**
 * كيان قاعدة البيانات لحفظ العقد في الأرشيف المحلي (Room Entity)
 */
@Entity(tableName = "saved_contracts")
data class ContractEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contractType: String, // REAL_ESTATE, CAR_SALE, RENTAL
    val title: String,
    val primaryPartyName: String, // اسم البائع أو المؤجر
    val secondaryPartyName: String, // اسم المشتري أو المستأجر
    val dateCreated: Long = System.currentTimeMillis(),
    val jsonContent: String // تسلسل البيانات بتنسيق JSON أو نص موحد
)
