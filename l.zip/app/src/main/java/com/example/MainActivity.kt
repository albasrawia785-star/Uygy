package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    HOME,
    REAL_ESTATE_FORM,
    CAR_SALE_FORM,
    RENTAL_FORM,
    SAVED_CONTRACTS
}

class MainActivity : ComponentActivity() {

    private val viewModel: ContractViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainContractAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContractAppScreen(viewModel: ContractViewModel) {
    val context = LocalContext.current

    val selectedType by viewModel.selectedContractType.collectAsStateWithLifecycle()
    val realEstateData by viewModel.realEstateContract.collectAsStateWithLifecycle()
    val carSaleData by viewModel.carSaleContract.collectAsStateWithLifecycle()
    val rentalData by viewModel.rentalContract.collectAsStateWithLifecycle()

    val previewBitmap by viewModel.previewBitmap.collectAsStateWithLifecycle()
    val showPreviewDialog by viewModel.showPreviewDialog.collectAsStateWithLifecycle()

    val printerState by viewModel.printerState.collectAsStateWithLifecycle()
    val pairedDevices by viewModel.pairedDevices.collectAsStateWithLifecycle()
    val selectedPaperType by viewModel.selectedPaperType.collectAsStateWithLifecycle()
    val showPrinterDialog by viewModel.showPrinterDialog.collectAsStateWithLifecycle()

    val savedContractsList by viewModel.savedContractsList.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // إذن البلوتوث بنظام أندرويد 12+
    val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            viewModel.openBluetoothPrinterDialog()
        } else {
            Toast.makeText(context, "يتطلب تطبيق الطباعة الإذن بالوصول للبلوتوث", Toast.LENGTH_SHORT).show()
        }
    }

    fun checkAndOpenBluetoothPrinter() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val connectGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED

            val scanGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED

            if (connectGranted && scanGranted) {
                viewModel.openBluetoothPrinterDialog()
            } else {
                bluetoothPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
            }
        } else {
            viewModel.openBluetoothPrinterDialog()
        }
    }

    Scaffold(
        topBar = {
            if (currentScreen != AppScreen.HOME) {
                TopAppBar(
                    title = {
                        val screenTitle = when (currentScreen) {
                            AppScreen.REAL_ESTATE_FORM -> "عقد بيع عقار"
                            AppScreen.CAR_SALE_FORM -> "عقد بيع سيارة"
                            AppScreen.RENTAL_FORM -> "عقد إيجار"
                            AppScreen.SAVED_CONTRACTS -> "سجل العقود المحفوظة"
                            else -> "عقود برو"
                        }
                        Text(
                            text = screenTitle,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 20.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { currentScreen = AppScreen.HOME }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "الرجوع للرئيسية",
                                tint = Color.White
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { checkAndOpenBluetoothPrinter() }) {
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = "طابعة البلوتوث",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F387A)
                    )
                )
            }
        },
        bottomBar = {
            AnimatedVisibility(
                visible = currentScreen in listOf(AppScreen.REAL_ESTATE_FORM, AppScreen.CAR_SALE_FORM, AppScreen.RENTAL_FORM),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // زر المعاينة وانشاء PDF
                        Button(
                            onClick = { viewModel.openPreviewDialog() },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("btn_preview_pdf"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F387A))
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("معاينة العقد A4", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        // زر الطباعة السريعة عبر البلوتوث (طابعة A4)
                        ElevatedButton(
                            onClick = { checkAndOpenBluetoothPrinter() },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("btn_direct_bluetooth_print"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.elevatedButtonColors(
                                containerColor = Color(0xFF008844),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("طباعة A4 بلوتوث", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreenUi(
                        onSelectRealEstate = {
                            viewModel.setContractType(ContractType.REAL_ESTATE)
                            currentScreen = AppScreen.REAL_ESTATE_FORM
                        },
                        onSelectCarSale = {
                            viewModel.setContractType(ContractType.CAR_SALE)
                            currentScreen = AppScreen.CAR_SALE_FORM
                        },
                        onSelectRental = {
                            viewModel.setContractType(ContractType.RENTAL)
                            currentScreen = AppScreen.RENTAL_FORM
                        },
                        onSelectSavedContracts = {
                            currentScreen = AppScreen.SAVED_CONTRACTS
                        },
                        onSelectPrinter = {
                            checkAndOpenBluetoothPrinter()
                        },
                        onSelectSettings = {
                            showSettingsDialog = true
                        },
                        onMenuClick = {
                            Toast.makeText(context, "منظومة عقود برو للطباعة الرسمية A4", Toast.LENGTH_SHORT).show()
                        },
                        onNotificationClick = {
                            Toast.makeText(context, "الطابعة متصلة وجاهزة لطباعة العقود", Toast.LENGTH_SHORT).show()
                        }
                    )
                }

                AppScreen.REAL_ESTATE_FORM -> {
                    RealEstateFormUi(
                        contract = realEstateData,
                        onContractChange = { update -> viewModel.updateRealEstateContract(update) }
                    )
                }

                AppScreen.CAR_SALE_FORM -> {
                    CarSaleFormUi(
                        contract = carSaleData,
                        onContractChange = { update -> viewModel.updateCarSaleContract(update) }
                    )
                }

                AppScreen.RENTAL_FORM -> {
                    RentalFormUi(
                        contract = rentalData,
                        onContractChange = { update -> viewModel.updateRentalContract(update) }
                    )
                }

                AppScreen.SAVED_CONTRACTS -> {
                    SavedContractsScreen(
                        contracts = savedContractsList,
                        onDeleteContract = { id -> viewModel.deleteSavedContract(id) }
                    )
                }
            }
        }
    }

    // 1. حوار معاينة العقد وإنشاء الـ PDF
    if (showPreviewDialog) {
        ContractPreviewDialog(
            bitmap = previewBitmap,
            onDismiss = { viewModel.closePreviewDialog() },
            onPrintBluetooth = {
                viewModel.closePreviewDialog()
                checkAndOpenBluetoothPrinter()
            },
            onSaveContract = {
                viewModel.saveContractToArchive()
            }
        )
    }

    // 2. حوار الطباعة عبر البلوتوث
    if (showPrinterDialog) {
        BluetoothPrinterDialog(
            printerState = printerState,
            pairedDevices = pairedDevices,
            selectedPaperType = selectedPaperType,
            onSelectPaperType = { type -> viewModel.setPrinterPaperType(type) },
            onRefreshDevices = { viewModel.refreshPairedDevices() },
            onSelectDevice = { device -> viewModel.printToBluetoothDevice(device) },
            onDismiss = { viewModel.closeBluetoothPrinterDialog() }
        )
    }

    // 3. حوار الإعدادات
    if (showSettingsDialog) {
        SettingsDialog(
            onDismiss = { showSettingsDialog = false },
            onOpenPrinterDialog = { checkAndOpenBluetoothPrinter() }
        )
    }
}
