package com.example

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ContractViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ContractRepository
    val bluetoothPrinterManager: BluetoothPrinterManager

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ContractRepository(database.contractDao())
        bluetoothPrinterManager = BluetoothPrinterManager(application)
        observeSavedContracts()
    }

    // 1. اختيار نوع العقد المباشر
    private val _selectedContractType = MutableStateFlow(ContractType.REAL_ESTATE)
    val selectedContractType: StateFlow<ContractType> = _selectedContractType.asStateFlow()

    // 2. حالات نماذج الإدخال للعقود الثلاثة
    private val _realEstateContract = MutableStateFlow(RealEstateContract())
    val realEstateContract: StateFlow<RealEstateContract> = _realEstateContract.asStateFlow()

    private val _carSaleContract = MutableStateFlow(CarSaleContract())
    val carSaleContract: StateFlow<CarSaleContract> = _carSaleContract.asStateFlow()

    private val _rentalContract = MutableStateFlow(RentalContract())
    val rentalContract: StateFlow<RentalContract> = _rentalContract.asStateFlow()

    // 3. حالة معاينة العقد وصورة الـ A4 Canvas
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _showPreviewDialog = MutableStateFlow(false)
    val showPreviewDialog: StateFlow<Boolean> = _showPreviewDialog.asStateFlow()

    // 4. حالة طباعة البلوتوث والأجهزة المقترنة
    val printerState: StateFlow<PrinterState> = bluetoothPrinterManager.printerState
    val selectedPaperType: StateFlow<PrinterPaperType> = bluetoothPrinterManager.selectedPaperType

    private val _pairedDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val pairedDevices: StateFlow<List<BluetoothDevice>> = _pairedDevices.asStateFlow()

    private val _showPrinterDialog = MutableStateFlow(false)
    val showPrinterDialog: StateFlow<Boolean> = _showPrinterDialog.asStateFlow()

    fun setPrinterPaperType(type: PrinterPaperType) {
        bluetoothPrinterManager.setPaperType(type)
    }

    // 5. الأرشيف والعقود المحفوظة
    private val _savedContractsList = MutableStateFlow<List<ContractEntity>>(emptyList())
    val savedContractsList: StateFlow<List<ContractEntity>> = _savedContractsList.asStateFlow()

    private fun observeSavedContracts() {
        viewModelScope.launch {
            repository.allContracts.collectLatest { list ->
                _savedContractsList.value = list
            }
        }
    }

    fun setContractType(type: ContractType) {
        _selectedContractType.value = type
        generateCurrentPreviewBitmap()
    }

    // تحديث بيانات عقد العقارات
    fun updateRealEstateContract(update: (RealEstateContract) -> RealEstateContract) {
        _realEstateContract.value = update(_realEstateContract.value)
    }

    // تحديث بيانات عقد السيارات
    fun updateCarSaleContract(update: (CarSaleContract) -> CarSaleContract) {
        _carSaleContract.value = update(_carSaleContract.value)
    }

    // تحديث بيانات عقد الإيجار
    fun updateRentalContract(update: (RentalContract) -> RentalContract) {
        _rentalContract.value = update(_rentalContract.value)
    }

    /**
     * توليد صورة معاينة A4 وفقاً للعقد الحالي
     */
    fun generateCurrentPreviewBitmap(): Bitmap {
        val bitmap = when (_selectedContractType.value) {
            ContractType.REAL_ESTATE -> FormGenerator.renderRealEstateContractBitmap(_realEstateContract.value)
            ContractType.CAR_SALE -> FormGenerator.renderCarSaleContractBitmap(_carSaleContract.value)
            ContractType.RENTAL -> FormGenerator.renderRentalContractBitmap(_rentalContract.value)
        }
        _previewBitmap.value = bitmap
        return bitmap
    }

    fun openPreviewDialog() {
        generateCurrentPreviewBitmap()
        _showPreviewDialog.value = true
    }

    fun closePreviewDialog() {
        _showPreviewDialog.value = false
    }

    /**
     * فتح حوار طباعة البلوتوث وتحديث قائمة الأجهزة
     */
    fun openBluetoothPrinterDialog() {
        refreshPairedDevices()
        _showPrinterDialog.value = true
    }

    fun closeBluetoothPrinterDialog() {
        _showPrinterDialog.value = false
        bluetoothPrinterManager.resetState()
    }

    fun refreshPairedDevices() {
        _pairedDevices.value = bluetoothPrinterManager.getPairedDevices()
    }

    fun printToBluetoothDevice(device: BluetoothDevice) {
        val bitmap = _previewBitmap.value ?: generateCurrentPreviewBitmap()
        viewModelScope.launch {
            bluetoothPrinterManager.printBitmapToBluetoothPrinter(device, bitmap)
        }
    }

    /**
     * حفظ العقد الحالي في قاعدة بيانات الأرشيف
     */
    fun saveContractToArchive() {
        viewModelScope.launch {
            val type = _selectedContractType.value
            val (title, primaryParty, secondaryParty, summaryJson) = when (type) {
                ContractType.REAL_ESTATE -> {
                    val c = _realEstateContract.value
                    Quad("عقد عقار - ${c.propertyType}", c.sellerName, c.buyerName, c.toString())
                }
                ContractType.CAR_SALE -> {
                    val c = _carSaleContract.value
                    Quad("عقد سيارة - ${c.carBrandAndType}", c.sellerName, c.buyerName, c.toString())
                }
                ContractType.RENTAL -> {
                    val c = _rentalContract.value
                    Quad("عقد إيجار - ${c.propertyLocation}", c.lessorName, c.lesseeName, c.toString())
                }
            }

            val entity = ContractEntity(
                contractType = type.name,
                title = title,
                primaryPartyName = primaryParty,
                secondaryPartyName = secondaryParty,
                jsonContent = summaryJson
            )
            repository.saveContract(entity)
        }
    }

    fun deleteSavedContract(id: Long) {
        viewModelScope.launch {
            repository.deleteContract(id)
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
