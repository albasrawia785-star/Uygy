package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ContractType

/**
 * شريط التنقل الرئيسي الفاخر بين قوالب العقود والسجلات
 */
@Composable
fun ContractTypeSelector(
    selectedType: ContractType,
    isArchiveSelected: Boolean,
    onSelectType: (ContractType) -> Unit,
    onSelectArchive: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // عقد عقارات
            SelectorTabItem(
                title = "عقارات A4",
                icon = Icons.Default.HomeWork,
                isSelected = !isArchiveSelected && selectedType == ContractType.REAL_ESTATE,
                testTag = "tab_real_estate",
                onClick = { onSelectType(ContractType.REAL_ESTATE) },
                modifier = Modifier.weight(1f)
            )

            // عقد سيارات
            SelectorTabItem(
                title = "مركبات A4",
                icon = Icons.Default.DirectionsCar,
                isSelected = !isArchiveSelected && selectedType == ContractType.CAR_SALE,
                testTag = "tab_car_sale",
                onClick = { onSelectType(ContractType.CAR_SALE) },
                modifier = Modifier.weight(1f)
            )

            // عقد إيجار
            SelectorTabItem(
                title = "إيجار A4",
                icon = Icons.Default.Key,
                isSelected = !isArchiveSelected && selectedType == ContractType.RENTAL,
                testTag = "tab_rental",
                onClick = { onSelectType(ContractType.RENTAL) },
                modifier = Modifier.weight(1f)
            )

            // السجل المحفوظ
            SelectorTabItem(
                title = "الأرشيف",
                icon = Icons.Default.FolderSpecial,
                isSelected = isArchiveSelected,
                testTag = "tab_archive",
                onClick = onSelectArchive,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SelectorTabItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
        label = "tabBg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "tabContent"
    )

    Box(
        modifier = modifier
            .testTag(testTag)
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = contentColor,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                color = contentColor,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

