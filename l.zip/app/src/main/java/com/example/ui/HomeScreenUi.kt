package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.outlined.Apartment
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * شاشة الرئيسية المطابقة لتصميم الصور والواجهة المطلوبة بالضبط (عقود برو)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreenUi(
    onSelectRealEstate: () -> Unit,
    onSelectCarSale: () -> Unit,
    onSelectRental: () -> Unit,
    onSelectSavedContracts: () -> Unit,
    onSelectPrinter: () -> Unit,
    onSelectSettings: () -> Unit,
    onMenuClick: () -> Unit,
    onNotificationClick: () -> Unit
) {
    val topBarColor = Color(0xFF0F387A)
    val pageBgColor = Color(0xFFF1F5F9)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBgColor)
    ) {
        // شريط العنوان العلوي الأزرق الداكن المطابق للصورة
        TopAppBar(
            title = {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "الرئيسية",
                        color = Color.White,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onMenuClick) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "القائمة",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            },
            actions = {
                IconButton(onClick = onNotificationClick) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "الإشعارات",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = topBarColor
            )
        )

        // محتوى الواجهة التفاعلي
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // الترحيب والعنوان الرئيسيين
            Text(
                text = "مرحباً بك في",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "عقود برو",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF0C2B5E),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "اختر نوع العقد",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            // صف كروت العقارات والسيارات
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // كارت عقد بيع عقار (أزرق)
                MainContractCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(150.dp)
                        .testTag("card_real_estate"),
                    title = "عقد بيع عقار",
                    icon = Icons.Outlined.Home,
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF0267D9), Color(0xFF004CB0))
                    ),
                    onClick = onSelectRealEstate
                )

                // كارت عقد بيع سيارة (أخضر)
                MainContractCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(150.dp)
                        .testTag("card_car_sale"),
                    title = "عقد بيع سيارة",
                    icon = Icons.Outlined.DirectionsCar,
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF10A34A), Color(0xFF097834))
                    ),
                    onClick = onSelectCarSale
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // كارت عقد إيجار (بنفسجي/إنديغو بعرض كامل)
            MainContractCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(135.dp)
                    .testTag("card_rental"),
                title = "عقد إيجار",
                icon = Icons.Outlined.Apartment,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF635BFF), Color(0xFF4C44E0))
                ),
                onClick = onSelectRental
            )

            Spacer(modifier = Modifier.height(20.dp))

            // صف 3 كروت للخدمات (العقود المحفوظة - الطباعة - الإعدادات)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // العقود المحفوظة
                ServiceActionCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(115.dp)
                        .testTag("card_saved_contracts"),
                    title = "العقود\nالمحفوظة",
                    icon = Icons.Outlined.Description,
                    onClick = onSelectSavedContracts
                )

                // الطباعة
                ServiceActionCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(115.dp)
                        .testTag("card_printer"),
                    title = "الطباعة",
                    icon = Icons.Outlined.Print,
                    onClick = onSelectPrinter
                )

                // الإعدادات
                ServiceActionCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(115.dp)
                        .testTag("card_settings"),
                    title = "الإعدادات",
                    icon = Icons.Outlined.Settings,
                    onClick = onSelectSettings
                )
            }

            Spacer(modifier = Modifier.height(36.dp))

            // عبارة الهوية الرسمية بالأسفل
            Text(
                text = "إدارة العقود الرسمية بكل احترافية",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * تصميم كارت نوع العقد الرئيسي الملون
 */
@Composable
private fun MainContractCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    brush: Brush,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .shadow(6.dp, RoundedCornerShape(20.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(brush)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(46.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * تصميم كروت الأزرار السفلية البيضاء
 */
@Composable
private fun ServiceActionCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .shadow(3.dp, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = Color.White
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color(0xFF0F2A4A),
                    modifier = Modifier.size(34.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = title,
                    color = Color(0xFF0F2A4A),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
