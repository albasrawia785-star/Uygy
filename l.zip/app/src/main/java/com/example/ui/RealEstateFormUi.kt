package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.RealEstateContract

@Composable
fun RealEstateFormUi(
    contract: RealEstateContract,
    onContractChange: ((RealEstateContract) -> RealEstateContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة رقم العقد والترويسة
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "عقد بيع وشراء عقار (A4)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { newVal -> onContractChange { it.copy(contractNo = newVal) } },
                    label = { Text("رقم العقد NO") },
                    singleLine = true,
                    modifier = Modifier.width(140.dp).testTag("input_real_estate_no"),
                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold)
                )
            }
        }

        // 1. قسم الطرف الأول (البائع)
        FormSectionTitle(title = "الطرف الأول ( البائع )", icon = Icons.Default.Person)
        OutlinedTextField(
            value = contract.sellerName,
            onValueChange = { valName -> onContractChange { it.copy(sellerName = valName) } },
            label = { Text("اسم البائع الثلاثي/الرباعي") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_seller_name")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { v -> onContractChange { it.copy(sellerAddress = v) } },
                label = { Text("العنوان / السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_seller_address")
            )
            OutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { v -> onContractChange { it.copy(sellerPhone = v) } },
                label = { Text("رقم الهاتف") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_seller_phone")
            )
        }

        OutlinedTextField(
            value = contract.sellerIdNumber,
            onValueChange = { v -> onContractChange { it.copy(sellerIdNumber = v) } },
            label = { Text("رقم الهوية الوطنية / البطاقة الموحدة") },
            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_seller_id")
        )

        // 2. قسم الطرف الثاني (المشتري)
        FormSectionTitle(title = "الطرف الثاني ( المشتري )", icon = Icons.Default.AccountBox)
        OutlinedTextField(
            value = contract.buyerName,
            onValueChange = { v -> onContractChange { it.copy(buyerName = v) } },
            label = { Text("اسم المشتري الثلاثي/الرباعي") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_buyer_name")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { v -> onContractChange { it.copy(buyerAddress = v) } },
                label = { Text("العنوان / السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_buyer_address")
            )
            OutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { v -> onContractChange { it.copy(buyerPhone = v) } },
                label = { Text("رقم الهاتف") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_buyer_phone")
            )
        }

        OutlinedTextField(
            value = contract.buyerIdNumber,
            onValueChange = { v -> onContractChange { it.copy(buyerIdNumber = v) } },
            label = { Text("رقم الهوية الوطنية / البطاقة الموحدة") },
            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_buyer_id")
        )

        // 3. مواصفات وتفاصيل العقار
        FormSectionTitle(title = "مواصفات العقار والملك المباع", icon = Icons.Default.HomeWork)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.propertyType,
                onValueChange = { v -> onContractChange { it.copy(propertyType = v) } },
                label = { Text("نوع الملك (دار/أرض/زراعي)") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_property_type")
            )
            OutlinedTextField(
                value = contract.propertyArea,
                onValueChange = { v -> onContractChange { it.copy(propertyArea = v) } },
                label = { Text("المساحة (م²)") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_property_area")
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.plotSequenceNo,
                onValueChange = { v -> onContractChange { it.copy(plotSequenceNo = v) } },
                label = { Text("الرقم والتسلسل") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_property_seq")
            )
            OutlinedTextField(
                value = contract.neighborhood,
                onValueChange = { v -> onContractChange { it.copy(neighborhood = v) } },
                label = { Text("المحلة / المنطقة") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_property_neighborhood")
            )
        }

        // 4. المبالغ والتسوية المالية
        FormSectionTitle(title = "المبالغ والشروط المالية", icon = Icons.Default.Money)
        OutlinedTextField(
            value = contract.totalPrice,
            onValueChange = { v -> onContractChange { it.copy(totalPrice = v) } },
            label = { Text("بدل البيع المتفق عليه (دينار)") },
            leadingIcon = { Icon(Icons.Default.Money, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_total_price")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.depositPrice,
                onValueChange = { v -> onContractChange { it.copy(depositPrice = v) } },
                label = { Text("العربون المقبوض") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_deposit_price")
            )
            OutlinedTextField(
                value = contract.remainingPrice,
                onValueChange = { v -> onContractChange { it.copy(remainingPrice = v) } },
                label = { Text("المبلغ المتبقي") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_remaining_price")
            )
        }

        // 5. التاريخ والشهود
        FormSectionTitle(title = "التاريخ والشهود", icon = Icons.Default.CalendarToday)
        OutlinedTextField(
            value = contract.contractDate,
            onValueChange = { v -> onContractChange { it.copy(contractDate = v) } },
            label = { Text("تاريخ العقد (مثال: 28/07/2026)") },
            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_contract_date")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { v -> onContractChange { it.copy(witness1Name = v) } },
                label = { Text("اسم الشاهد الأول") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_witness1")
            )
            OutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { v -> onContractChange { it.copy(witness2Name = v) } },
                label = { Text("اسم الشاهد الثاني") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_witness2")
            )
        }

        OutlinedTextField(
            value = contract.additionalNotes,
            onValueChange = { v -> onContractChange { it.copy(additionalNotes = v) } },
            label = { Text("ملاحظات أو شروط إضافية") },
            modifier = Modifier.fillMaxWidth().height(100.dp).testTag("input_additional_notes")
        )
    }
}

@Composable
fun FormSectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 4.dp)
    ) {
        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}
