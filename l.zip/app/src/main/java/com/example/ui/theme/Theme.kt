package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ExecutiveDarkColorScheme = darkColorScheme(
    primary = Color(0xFF93C5FD),
    onPrimary = Navy900,
    primaryContainer = Navy800,
    onPrimaryContainer = Color.White,
    secondary = Gold600,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF451A03),
    onSecondaryContainer = Gold100,
    tertiary = Color(0xFFFCA5A5),
    background = Navy900,
    onBackground = Navy50,
    surface = Navy800,
    onSurface = Navy50,
    surfaceVariant = Navy700,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = SlateGrey
)

private val ExecutiveLightColorScheme = lightColorScheme(
    primary = Navy900,
    onPrimary = Color.White,
    primaryContainer = Navy100,
    onPrimaryContainer = Navy900,
    secondary = Gold700,
    onSecondary = Color.White,
    secondaryContainer = Gold100,
    onSecondaryContainer = Gold700,
    tertiary = Crimson800,
    onTertiary = Color.White,
    tertiaryContainer = Crimson100,
    onTertiaryContainer = Crimson800,
    background = Navy50,
    onBackground = Navy900,
    surface = Color.White,
    onSurface = Navy900,
    surfaceVariant = Navy100,
    onSurfaceVariant = Navy800,
    outline = SlateGrey,
    outlineVariant = SlateBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ExecutiveDarkColorScheme else ExecutiveLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

